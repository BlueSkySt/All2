🧨 This script is encoded to prevent skido change script🧨

#Clone and Install Script

> git clone https://github.com/DarlingSh1337/HTTP-SENPAI/

> cd HTTP-SENPAI


#Installation Tutoriel for Skido

> npm i cloudscraper

> npm i request

> CREATE OR UPDATE HTTP.TXT FILE IN DIRECTORY and pute PROXYLIST on it


#Launch Script

> node hentai.js url proxylist.txt time method

> node hentai.js https://check-host.net/check-http?host=https://www.brazzers.com/join http.txt 60 GET
